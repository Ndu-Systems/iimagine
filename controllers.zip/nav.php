	<!-- header -->
		<div class="header">
            <div class="logo" style="width: 30%;">
                <!--<h1><a href="#/"><span>N</span>du-system.net</a></h1>-->
                <a href="Home.php"> <img src="images/logo.png" style="width:40%" /></a>
            </div>   
			<div class="clearfix"> </div>
		</div>
		<!-- //header -->
		<!-- top-nav -->
		<nav class="cd-stretchy-nav edit-content">
			<a class="cd-nav-trigger" href="#0"> Menu <span aria-hidden="true"></span> </a>
			<ul>
				<li><a href="Home.php" class="scroll active"><span>HOME</span></a></li>
		    	<li><a href="Our-Services.php"><span>OUR SERVICES</span></a></li>   
		  		<li><a href="Contact-Us.php"><span>CONTACT US</span></a></li>              
			</ul>        
			<span aria-hidden="true" class="stretchy-nav-bg"></span>
		</nav> 